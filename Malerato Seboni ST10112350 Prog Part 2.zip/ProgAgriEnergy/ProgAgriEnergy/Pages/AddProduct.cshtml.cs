using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProgAgriEnergy.Pages
{
    public class AddProductModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
