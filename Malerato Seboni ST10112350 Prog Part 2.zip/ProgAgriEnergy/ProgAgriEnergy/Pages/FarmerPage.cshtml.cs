using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProgAgriEnergy.Pages
{
    public class FarmerPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
