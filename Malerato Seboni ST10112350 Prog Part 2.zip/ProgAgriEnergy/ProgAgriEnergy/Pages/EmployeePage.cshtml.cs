using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProgAgriEnergy.Pages
{
    public class EmployeePageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
