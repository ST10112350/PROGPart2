using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProgAgriEnergy.DatabaseClasses;

namespace ProgAgriEnergy.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
            // Code for handling the GET request
        }
    }
}
