﻿namespace ProgAgriEnergy.DatabaseClasses
{
    public class RoleClass
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
