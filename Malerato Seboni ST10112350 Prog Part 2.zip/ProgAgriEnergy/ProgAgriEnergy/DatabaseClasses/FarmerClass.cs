﻿namespace ProgAgriEnergy.DatabaseClasses
{
    public class FarmerClass
    {
        public int FarmerId { get; set; }
        public string Name { get; set; }
        public int UserId { get; set; }
        public UserClass User { get; set; }
        public List<ProductClass> Products { get; set; }
    }
}
