﻿namespace ProgAgriEnergy.DatabaseClasses
{
    public class UserClass
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public int RoleId { get; set; }
        public RoleClass Role { get; set; }
    }
}
