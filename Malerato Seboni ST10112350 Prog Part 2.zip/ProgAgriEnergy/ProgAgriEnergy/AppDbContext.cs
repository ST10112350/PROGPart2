﻿using Microsoft.EntityFrameworkCore;
using ProgAgriEnergy.DatabaseClasses;
using System;
using System.Collections.Generic;

namespace ProgAgriEnergy
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // Define your DbSet properties for each entity/table
        public DbSet<UserClass> Users { get; set; }
        public DbSet<RoleClass> Roles { get; set; }
        public DbSet<ProductClass> Products { get; set; }
        // Other DbSet properties

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure your entity relationships, constraints, etc.

            // Seed initial roles
            modelBuilder.Entity<RoleClass>().HasData(
                new RoleClass { RoleId = 1, RoleName = "Farmer" },
                new RoleClass { RoleId = 2, RoleName = "Employee" }
            );

            // Seed initial products
            modelBuilder.Entity<ProductClass>().HasData(
                new ProductClass { ProductId = 1, Name = "Seed", Category = "Agriculture", ProductionDate = DateTime.Now, FarmerId = 1 },
                new ProductClass { ProductId = 2, Name = "Farming Equipment", Category = "Agriculture", ProductionDate = DateTime.Now, FarmerId = 1 }
                // Add more products as needed
            );

        }
    }
}

